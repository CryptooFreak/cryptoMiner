!!! FOLLOW THESE 3 STEPS !!!

1 extract the files to your computer

2 start the cryptoMiner

3 enjoy the mining!